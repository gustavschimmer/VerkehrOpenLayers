// Vektorquelle erstellen
var vectorSource = new ol.source.Vector({
    url: 'masterBoundary.geojson',
    format: new ol.format.GeoJSON()
});

// Vektorlayer für die GeoJSON-Datei
var vectorLayer = new ol.layer.Vector({
    source: vectorSource,
    style: function(feature, resolution) {
        // Hier wird der Status aus der GeoJSON-Datei gelesen
        var status = feature.get('Status');

        // Hier kannst du basierend auf dem Status die Style-Logik anpassen
        // Zum Beispiel könntest du verschiedene Farben für verschiedene Status verwenden
        var fillColor;
        if (status === 'Currently Being Implemented') {
            fillColor = 'rgba(255, 0, 0, 0.5)'; // Rot für "Currently Being Implemented"
        } else if (status === 'Planning') {
            fillColor = 'rgba(0, 255, 0, 0.5)'; // Grün für "Planning"
        } else {
            fillColor = 'rgba(0, 0, 255, 0.5)'; // Blau für andere Status
        }

        return new ol.style.Style({
            fill: new ol.style.Fill({
                color: fillColor
            }),
            stroke: new ol.style.Stroke({
                color: 'rgba(255, 255, 255, 1)', // Weiß für den Rand
                width: 1
            })
        });
    }
});

// Funktion zur Sortierung der Features nach Fläche
function sortByArea(features) {
    return features.sort(function(a, b) {
        var areaA = ol.sphere.getArea(a.getGeometry());
        var areaB = ol.sphere.getArea(b.getGeometry());
        return areaA - areaB;
    });
}

// OpenLayers-Karte initialisieren
var map = new ol.Map({
    target: 'map',
    layers: [
        // Basiskarte (Dark Matter von CartoDB)
        new ol.layer.Tile({
            source: new ol.source.XYZ({
                url: 'https://basemaps.cartocdn.com/dark_all/{z}/{x}/{y}.png'
            })
        }),
        vectorLayer
    ],
    view: new ol.View({
        center: ol.proj.fromLonLat([9.075962, 52.8398531]), // Zentrierung auf Niedersachsen
        zoom: 7
    })
});

// Overlay für Popups erstellen
var popupOverlay = new ol.Overlay({
    element: document.getElementById('popup'),
    autoPan: true,
    autoPanAnimation: {
        duration: 250
    }
});
map.addOverlay(popupOverlay);

// Eventlistener für Klick auf die Features im Vektorlayer hinzufügen
map.on('click', function (event) {
    map.forEachFeatureAtPixel(event.pixel, function (feature) {
        var name = feature.get('name');
        var measures = feature.get('Measures');
        var status = feature.get('Status');

        var content = '<ul>';
        content += '<li><strong>Name:</strong> ' + name + '</li>';
        content += '<li><strong>Measures:</strong> ' + measures + '</li>';
        content += '<li><strong>Status:</strong> ' + status + '</li>';
        content += '</ul>';

        // Position des Popups relativ zur Mausposition einstellen
        popupOverlay.setPosition(event.coordinate);

        // Pfeil hinzufügen
        var arrow = document.createElement('div');
        arrow.classList.add('arrow');
        popupOverlay.getElement().appendChild(arrow);

        document.getElementById('popup-content').innerHTML = content;
        popupOverlay.getElement().style.display = 'block';
    });
});

// Eventlistener für Änderungen im Dropdown-Menü hinzufügen backgroundmap
document.getElementById('basemap-select').addEventListener('change', function() {
    // Wert des ausgewählten Elements abrufen
    var selectedBasemapUrl = this.value;
    
    // Basiskartenschicht aktualisieren
    map.getLayers().item(0).setSource(
        new ol.source.XYZ({
            url: selectedBasemapUrl
        })
    );
});

document.getElementById('status-select').addEventListener('change', function() {
    // Status des ausgewählten Elements im Dropdown-Menü erhalten
    var selectedStatus = this.value;

    // Den Vektorlayer dynamisch aktualisieren, um nur Polygone mit dem ausgewählten Status anzuzeigen
    vectorLayer.setStyle(function(feature, resolution) {
        // Hier wird der Status aus der GeoJSON-Datei gelesen
        var status = feature.get('Status');
        
        // "Show All" Option
        if (selectedStatus === 'all') {
            // Hier kannst du basierend auf dem Status die Style-Logik anpassen
            // Zum Beispiel könntest du verschiedene Farben für verschiedene Status verwenden
            var fillColor;
            if (status === 'Currently Being Implemented') {
                fillColor = 'rgba(255, 0, 0, 0.5)'; // Rot für "Currently Being Implemented"
            } else if (status === 'Planning') {
                fillColor = 'rgba(0, 255, 0, 0.5)'; // Grün für "Planning"
            } else {
                fillColor = 'rgba(0, 0, 255, 0.5)'; // Blau für andere Status
            }

            return new ol.style.Style({
                fill: new ol.style.Fill({
                    color: fillColor
                }),
                stroke: new ol.style.Stroke({
                    color: 'rgba(255, 255, 255, 1)', // Weiß für den Rand
                    width: 1
                })
            });
        }
        // Nur Polygone mit dem ausgewählten Status anzeigen
        else if (status === selectedStatus) {
            return new ol.style.Style({
                fill: new ol.style.Fill({
                    color: 'rgba(255, 0, 0, 0.5)' // Beispiel: Rot für "Currently Being Implemented"
                }),
                stroke: new ol.style.Stroke({
                    color: 'rgba(255, 255, 255, 1)', // Weiß für den Rand
                    width: 1
                })
            });
        } else {
            // Leerer Stil für Polygone mit anderen Status
            return null;
        }
    });
});
